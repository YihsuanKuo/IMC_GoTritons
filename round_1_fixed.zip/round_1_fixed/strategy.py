from datamodel import OrderDepth, TradingState, Order
from typing import Dict, List
import json
import math


class Trader:
    ASH_PRODUCT = "ASH_COATED_OSMIUM"

    POSITION_LIMITS = {
        ASH_PRODUCT: 80,
    }

    ASH_HISTORY_LENGTH = 3
    ASH_ENTRY_Z = 1.0
    ASH_EXIT_Z = 0.4
    ASH_BASE_QUOTE_OFFSET = 1
    ASH_INVENTORY_SKEW = 0.02

    def __init__(self):
        self.position = 0
        self.mid_history = []

    def bid(self):
        return 15

    def send_sell_order(self, orders, product, price, amount):
        if amount != 0:
            orders.append(Order(product, int(price), int(amount)))

    def send_buy_order(self, orders, product, price, amount):
        if amount != 0:
            orders.append(Order(product, int(price), int(amount)))

    def get_product_pos(self, state, product):
        return state.position.get(product, 0)

    def load_saved_data(self, state):
        if not state.traderData:
            return {}
        try:
            saved = json.loads(state.traderData)
            return saved if isinstance(saved, dict) else {}
        except Exception:
            return {}

    def load_history(self, saved_data):
        ash_data = saved_data.get(self.ASH_PRODUCT, {})
        self.mid_history = (
            ash_data.get("mid_history", [])
            if isinstance(ash_data, dict)
            else []
        )

    def save_data(self):
        return json.dumps(
            {
                self.ASH_PRODUCT: {
                    "mid_history": self.mid_history[-self.ASH_HISTORY_LENGTH :]
                }
            }
        )

    def get_mid_price(self, order_depth):
        if not order_depth.buy_orders or not order_depth.sell_orders:
            return None
        return (
            max(order_depth.buy_orders.keys())
            + min(order_depth.sell_orders.keys())
        ) / 2

    def update_mid_history(self, mid):
        self.mid_history.append(mid)
        if len(self.mid_history) > self.ASH_HISTORY_LENGTH:
            self.mid_history.pop(0)

    def get_mean_std(self):
        if not self.mid_history:
            return None, None
        mean = sum(self.mid_history) / len(self.mid_history)
        var = sum((x - mean) ** 2 for x in self.mid_history) / len(
            self.mid_history
        )
        return mean, math.sqrt(var)

    def get_zscore(self, mid):
        mean, std = self.get_mean_std()
        if mean is None or std < 1e-6:
            return 0, mid
        return (mid - mean) / std, mean

    def get_mm_size(self, position: int) -> int:
        a = abs(position)
        if a < 20:
            return 10
        elif a < 50:
            return 6
        else:
            return 3

    def trade_ash_coated_osmium(self, state, orders):
        od = state.order_depths[self.ASH_PRODUCT]
        mid = self.get_mid_price(od)
        if mid is None:
            return

        self.update_mid_history(mid)
        z, mean = self.get_zscore(mid)

        best_bid = max(od.buy_orders.keys())
        best_ask = min(od.sell_orders.keys())

        limit = self.POSITION_LIMITS[self.ASH_PRODUCT]
        est_pos = self.position

        # mean reversion taking with capacity awareness
        if z < -self.ASH_ENTRY_Z:
            buy_cap = limit - est_pos
            for ask, vol in sorted(od.sell_orders.items()):
                if ask <= mean and buy_cap > 0:
                    size = min(-vol, buy_cap)
                    if size > 0:
                        self.send_buy_order(
                            orders, self.ASH_PRODUCT, ask, size
                        )
                        est_pos += size
                        buy_cap -= size

        elif z > self.ASH_ENTRY_Z:
            sell_cap = limit + est_pos
            for bid, vol in sorted(od.buy_orders.items(), reverse=True):
                if bid >= mean and sell_cap > 0:
                    size = min(vol, sell_cap)
                    if size > 0:
                        self.send_sell_order(
                            orders, self.ASH_PRODUCT, bid, -size
                        )
                        est_pos -= size
                        sell_cap -= size

        # market making with inventory-adjusted fair
        fair = mean - self.ASH_INVENTORY_SKEW * est_pos
        bid_price = min(best_bid + 1, int(fair - self.ASH_BASE_QUOTE_OFFSET))
        ask_price = max(best_ask - 1, int(fair + self.ASH_BASE_QUOTE_OFFSET))

        mm_size = self.get_mm_size(est_pos)

        buy_cap = limit - est_pos
        sell_cap = limit + est_pos

        if buy_cap > 0:
            self.send_buy_order(
                orders, self.ASH_PRODUCT, bid_price, min(mm_size, buy_cap)
            )
        if sell_cap > 0:
            self.send_sell_order(
                orders, self.ASH_PRODUCT, ask_price, -min(mm_size, sell_cap)
            )

    def run(self, state: TradingState):
        result: Dict[str, List[Order]] = {self.ASH_PRODUCT: []}

        saved_data = self.load_saved_data(state)
        self.load_history(saved_data)

        if self.ASH_PRODUCT not in state.order_depths:
            return result, 0, self.save_data()

        order_depth = state.order_depths[self.ASH_PRODUCT]
        orders: List[Order] = []

        if (
            len(order_depth.buy_orders) == 0
            or len(order_depth.sell_orders) == 0
        ):
            result[self.ASH_PRODUCT] = orders
            return result, 0, self.save_data()

        self.position = self.get_product_pos(state, self.ASH_PRODUCT)
        self.trade_ash_coated_osmium(state, orders)

        result[self.ASH_PRODUCT] = orders
        return result, 0, self.save_data()
